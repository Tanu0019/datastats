/** Automatically generated file. DO NOT MODIFY */
package com.cylon.widget;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}